%% OAEPRL Processing Shortcuts Generator Boogie 1.03
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% OAEPRL EPR Processings Package, Version 1.03
% Last Modified 2/19/2010

clear all; % clears all of the variables and structures

iconfile = which('oaeprl.gif'); % Finds the icon in the Matlab paths
isEditable = 'true'; % Allows the shortcuts to be writeable

name = 'ASCII Conversion'; % The shortcut name
evalstr = 'textconvert'; % Shortcut target

awtinvoke(com.mathworks.mlwidgets.shortcuts.ShortcutUtils,'addShortcutToBottom',name,evalstr,iconfile,'Toolbar Shortcuts',isEditable); % Creates the shortcut

name = 'Concentration'; % The shortcut name
evalstr = 'concentration'; % Shortcut target

awtinvoke(com.mathworks.mlwidgets.shortcuts.ShortcutUtils,'addShortcutToBottom',name,evalstr,iconfile,'Toolbar Shortcuts',isEditable); % Creates the shortcut

name = 'Power Saturation'; % The shortcut name
evalstr = 'powersat'; % Shortcut target

awtinvoke(com.mathworks.mlwidgets.shortcuts.ShortcutUtils,'addShortcutToBottom',name,evalstr,iconfile,'Toolbar Shortcuts',isEditable); % Creates the shortcut

name = 'T1 Fit'; % The shortcut name
evalstr = 't1fit'; % Shortcut target

awtinvoke(com.mathworks.mlwidgets.shortcuts.ShortcutUtils,'addShortcutToBottom',name,evalstr,iconfile,'Toolbar Shortcuts',isEditable); % Creates the shortcut

name = 'T2 Fit'; % The shortcut name
evalstr = 't2fit'; % Shortcut target

awtinvoke(com.mathworks.mlwidgets.shortcuts.ShortcutUtils,'addShortcutToBottom',name,evalstr,iconfile,'Toolbar Shortcuts',isEditable); % Creates the shortcut

name = '2P ESEEM'; % The shortcut name
evalstr = 'ESEEM2pproc'; % Shortcut target

awtinvoke(com.mathworks.mlwidgets.shortcuts.ShortcutUtils,'addShortcutToBottom',name,evalstr,iconfile,'Toolbar Shortcuts',isEditable); % Creates the shortcut

name = '3P ESEEM'; % The shortcut name
evalstr = 'ESEEM3pproc'; % Shortcut target

awtinvoke(com.mathworks.mlwidgets.shortcuts.ShortcutUtils,'addShortcutToBottom',name,evalstr,iconfile,'Toolbar Shortcuts',isEditable); % Creates the shortcut

