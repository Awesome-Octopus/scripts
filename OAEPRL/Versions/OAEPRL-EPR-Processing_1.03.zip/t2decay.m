%% T2 Decay Function
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% OAEPRL EPR Processings Package, Version 1.03
% Last Modified 2/19/2010

function f = t2decay(x,b,spec,params) % Sets up the t2decay function (goes with t2fit)
f = ((sum(abs(spec-((x(1)*exp(-b/x(2))))))).^2/params.XPTS).^0.5; % The T2 decay function
