%% 2-Pulse ESEEM Processing Package
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% OAEPRL EPR Processings Package, Version 1.0
% Last Modified 1/12/2010

clear all  % Clears all variables and structures

%% Read in the Bruker EPR File

[b spec params] = eprload(); % Uses EasySpin eprload function to read in data
[shift ns] = strread(params.FTEzDelay1,'%f %s'); % Reads in the value of tau (d1)
[shift2 ns2] = strread(params.FTEzDelay2,'%f %s'); % Reads in the value of T (d2)
b = (b' + shift + shift2); % Shifts the x axis values by tau (d1) + T (d2)
spec = real(spec'); % Removes the imaginary component of the y data

%% Background Subtraction and Scaling to 1

[k,c,yfit] = exponfit(b,spec,2); % Uses the EasySpin function expnfit to fit the background
scale = max(yfit); % Establishes the maximum of the exponential fit as a scaling factor
spec_scaled = spec/max(scale); % Scales the experimental data
yfit_scaled = yfit/max(scale); % Scales the exponential background
ysub = spec_scaled-yfit_scaled; % Subtracts the background function

%% Calculate Fouier Transform

[inc ns] = strread(params.FTEzDeltaX,'%f %s'); % Reads the time increment from the paramaters structure
xf = fdaxis(inc/1000,params.XPTS*2); % Uses the EasySpin fdaxis function to generate an x axis for the FT
ft = real(ctafft(ysub,params.XPTS-1,params.XPTS*2)); % Constructs the Cross Term Averaged FFT of the experimental data
ft = fftshift(ft); % Shifts the FFT using the Matlab function fftshift to obtain the correct spectrum

%% Plot the Data

subplot(3,1,1); % Establishes a subplot
plot(b,spec_scaled,b,yfit_scaled); % Plots the scaled experimental and exponential fit
xlabel('\tau+T(ns)','FontSize',14), ylabel('normalized intensity','FontSize',14); % Constructs the axes labels
title('Normalized Time Domain','FontSize',16); % Constructs the title
subplot(3,1,2); % Establishes a subplot
plot(b,ysub); % Plots the subtracted data
xlabel('\tau+T(ns)','FontSize',14), ylabel('intensity','FontSize',14); % Constructs the axes labels
title('Subtracted Time Domain','FontSize',16); % Constructs the title
subplot(3,1,3); % Establishes a subplot
plot(xf,ft); % Plots the FT
xlabel('frequency(MHz)','FontSize',14), ylabel('intensity','FontSize',14); % Constructs the axes labels
title('Fourier Transform','FontSize',16); % Constructs the title
axis([0 max(xf) 0 max(ft)*1.2]); % Limits the x axis of the plot to the positive values of the FT

%% Save an ASCII File with the Initial Data, Background, Subtraction and FT

fnametime = sprintf('%s_time.txt',params.TITL); % Reads in the filename
fnameft = sprintf('%s_FT.txt',params.TITL); % Appends _FT.txt to the filename
datatime = [b' spec' yfit' spec_scaled' yfit_scaled' ysub']; % Creates an array with the time data
dataft = [xf' ft']; % Creates an array with the FT data
save(fnametime,'datatime','-ascii'); % Saves an ASCII file of the time data
save(fnameft,'dataft','-ascii'); % Saves and ASCII file of the FT data