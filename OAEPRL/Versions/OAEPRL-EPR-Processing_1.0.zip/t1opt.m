%% Optimum SRT Function
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% OAEPRL EPR Processings Package, Version 1.0
% Last Modified 1/14/2010

function f = t1opt(x,b,spec,params) % Sets up the t1opt function (goes with t1fit)
opt = ((1./b.*((sum(abs(spec-(x(1)*(1-2*exp(-b/x(2)))+x(3))))).^2/params.XPTS).^0.5).^0.5).^2; % The T1 optimization function
f = max(opt); % Maximum value of the T1 optimization function