clear all;
[x y params] = eprload('136 Time.spc')
x = x'
ysmooth = smooth(y,10)
[m n] = size(y)

mmaxa = round(0.4*m)
mmaxb = round(0.5*m)
mmina = round(0.5*m)
mminb = round(0.6*m)
for i=1:params.SSY
height(1,i) = max(ysmooth(mmaxa:mmaxb,i))-min(ysmooth(mmina:mminb,i))
time(1,i) = params.JNS*params.SSX*params.RTC*0.001/60*i
end
height = height'
time = time'
plot(time,height)

data = [x y]
processed = [time height]

save('136_data.txt','data','-ascii');
save('136_processed.txt','processed','-ascii');
