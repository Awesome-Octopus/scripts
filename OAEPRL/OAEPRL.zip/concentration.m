
%% Concentration Determination Package
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% OAEPRL EPR Processings Package, Version 2.0
% Last Modified 7/25/2017

clear all; % clears all of the variables and structures

%% Read in Bruker Binary File and Establish Constants

slope = 13.5 % Standard from experiment
offset = 1.5289;
[x y params] = eprload(); % Uses EasySpin eprload function to read in data
height = input('Sample Height (mm): ','s'); % Prompts the user for the sample height
height = str2num(height); % converts the input string into a floating point number

%% Smooth and Integrate the Data

smoothy = datasmooth(y,10);
inty = cumtrapz(x,smoothy);
dblinty = cumtrapz(x,inty);
maxint = ((max(dblinty)/params.JSD)/params.RRG)-offset;

%% Determine the Concentation

heightfactor = (1-exp(-height/7.5)); % Scaling for sample volume
conc = (maxint*slope)*heightfactor;

%% Plot the Data

plot(x,y); % plots the spectrum
xlabel('Field (G)','FontSize',14), ylabel('d\chi"/dB','FontSize',14); % Constructs the axes labels
title('CW EPR Spectrum','FontSize',16); % Construacts the title
conclabel = [sprintf('Concentration = %.0f ',conc) '\muM']; % Assigns a string to the obtained value for T1 on the plot
text(min(x)+(max(x)-min(x))/20,min(y)+(max(y)-min(y))/200,conclabel,'FontSize',18,'color','r'); % Prints the T1 string on the plot


% 1.6778 1.4563 1.3062 1.6753 120 128 127 59 62 54