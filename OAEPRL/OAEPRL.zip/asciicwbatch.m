%% CW EPR Batch ACSII Conversion Tool
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% OAEPRL EPR Processings Package, Version 1.14
% Last Modified 09/29/2015

clear all

%% Creates a structure named files with a list of all the files in the
% current directory

files = dir('*.spc')

%% A for loop that cycles through all of the files in the directory, loads
% them in using EasySpin, creates a filename with a .txt extension from the
% original filename and saves an ASCII file

for file = files' % runs a for loop through the files
    [x,y] = eprload(file.name);
    fname = file.name(1:end-4); % removes the *spc from the filename
    textname = sprintf('%s.txt',fname); % adds .txt
    data = [x',y];
    save(textname,'data','-ascii');
end