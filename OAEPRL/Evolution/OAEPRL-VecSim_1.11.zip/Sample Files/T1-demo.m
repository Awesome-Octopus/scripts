clear all

%% Creates a matrix of spins along the z axis

for i=1:1
    Spins.degrees(i,:) = [0,0,1];
end

%% Sets the parameters and function for first pi pulse

Pulse.direction = 'y';
Pulse.angle = 180;
Pulse.delay = 0.002;

Spins.degrees = pulse(Spins,Pulse);

%% Sets the evolution parameters and function between pulses

Spins.Tone = 0.0002;
Spins.Ttwo = 0.000002;
Spins.offset = linspace(0,0,1);

Sim.length = 0.002;
Sim.inc = 0.00002;
Sim.delay = 0.1;

Spins.degrees = evolution(Spins,Sim);