%% Bloch Evolution Function
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% Pulse EPR Vector Simulation Package, Version 1.1
% Last Modified 05/18/2011

function [Spinsout,Frameout]=evolution(Spins,Sim)


%% Checks for variables and falls back on a default value if missing

if (isfield(Sim,'video') == 0);
    Sim.video='n';
end

if (isfield(Spins,'Tone') == 0);
    Spins.Tone=0.0002;
end

if (isfield(Spins,'Ttwo') == 0);
    Spins.Ttwo=0.000002;
end

if (isfield(Sim,'length') == 0);
    Sim.length=0.0000005;
end

if (isfield(Sim,'inc') == 0);
    Sim.inc=0.00000001;
end

if (isfield(Sim,'delay') == 0);
    Sim.delay=0.05;
end

%% Gets the number of spins in the array

mdegrees = size(Spins.degrees);
starts = zeros(mdegrees(1),3);

%% Converts spins to rectangular coordinates
for i=1:mdegrees(1)
    x = sin(Spins.degrees(i,2)/360*2*pi)*cos(Spins.degrees(i,1)/360*2*pi)*Spins.degrees(i,3);
    y = sin(Spins.degrees(i,2)/360*2*pi)*sin(Spins.degrees(i,1)/360*2*pi)*Spins.degrees(i,3);
    z = cos(Spins.degrees(i,2)/360*2*pi)*Spins.degrees(i,3);
    coordinates(i,:)=[x,y,z];
end

%% Creates time axes for the plots
time = 0:Sim.inc:Sim.length;
xsum = zeros(1,numel(time));
ysum = zeros(1,numel(time));
zsum = zeros(1,numel(time));

%% Calculates the xy and z projections for T1 and T2 decays
for m=1:mdegrees(1)
    xyprojection(m) = (coordinates(m,1)^2+coordinates(m,2)^2)^0.5;
    zprojection(m) = coordinates(m,3);
end

%% Conducts the rotaition about z and plots the results

if (Sim.video == 'n');    
   

%% Performs the incremental rotation
for i=1:numel(time)
    for j=1:mdegrees(1)
        theta=2*pi*Spins.offset(j)*Sim.inc;
        rotmat=[cos(-theta) -sin(-theta) 0;sin(-theta) cos(-theta) 0;0 0 1];
        scale=xyprojection(j).*(2.71828183^(-time(i)./Spins.Ttwo));
        coordinates(j,:) = coordinates(j,:)*rotmat;
        relaxation(j,1)=coordinates(j,1).*scale/xyprojection(j);
        relaxation(j,2)=coordinates(j,2).*scale/xyprojection(j);
        relaxation(j,3)=1+(zprojection(j)-1).*(2.71828183^(-time(i)./Spins.Tone));
        ends(j,:)=relaxation(j,:);
    end
    xsum(1,i)=round(sum(ends(:,1))/mdegrees(1)*100)/100;
	ysum(1,i)=round(sum(ends(:,2))/mdegrees(1)*100)/100;
    zsum(1,i)=round(sum(ends(:,3))/mdegrees(1)*100)/100;
    subplot(1,2,1)
    quiver3(starts(:,1),starts(:,2),starts(:,3),ends(:,1),ends(:,2),ends(:,3));
    xlabel('x');
    ylabel('y');
    zlabel('z');
    title('Vector Diagram Simulation');
    axis ([-1 1 -1 1 -1 1]);
    subplot(3,2,2);
    plot(time,xsum);
    title('x Magnetization');
    axis([min(time) max(time) -1 1]);
    subplot(3,2,4);
    plot(time,ysum);
    title('y Magnetization');
    axis([min(time) max(time) -1 1]);
    subplot(3,2,6);
    plot(time,zsum);
    title('z Magnetization');
    axis([min(time) max(time) -1 1]);
    pause(Sim.delay);
end

for k=1:mdegrees(1)
    r(k)=((ends(k,1)-0)^2+(ends(k,2)-0)^2+(ends(k,3)-0)^2)^0.5;
end

angles = vec2ang(ends)'*180/3.14159265358979323846;
Spinsout = [angles r'];
Frameout = 0;

%% Conducts the rotaition about z and plots the resultsand outputs PNG

elseif (Sim.video == 'y');

if (isfield(Sim,'frame') == 0);
    Sim.frame=10000;
end
    
for i=1:numel(time)
    for j=1:mdegrees(1)
        scale=xyprojection(j).*(2.71828183^(-time(i)./Spins.Ttwo));
        coordinates(j,:) = coordinates(j,:)*rotaxi2mat([0;0;1],2*pi*Spins.offset(j)*Sim.inc);
        relaxation(j,1)=coordinates(j,1).*scale/xyprojection(j);
        relaxation(j,2)=coordinates(j,2).*scale/xyprojection(j);
        relaxation(j,3)=1+(zprojection(j)-1).*(2.71828183^(-time(i)./Spins.Tone));
        ends(j,:)=relaxation(j,:);
    end
    xsum(1,i)=round(sum(ends(:,1))/mdegrees(1)*100)/100;
	ysum(1,i)=round(sum(ends(:,2))/mdegrees(1)*100)/100;
    zsum(1,i)=round(sum(ends(:,3))/mdegrees(1)*100)/100;
    subplot(1,2,1)
    quiver3(starts(:,1),starts(:,2),starts(:,3),ends(:,1),ends(:,2),ends(:,3));
    xlabel('x');
    ylabel('y');
    zlabel('z');
    title('Vector Diagram Simulation');
    axis ([-1 1 -1 1 -1 1]);
    subplot(3,2,2);
    plot(time,xsum);
    title('x Magnetization');
    axis([min(time) max(time) -1 1]);
    subplot(3,2,4);
    plot(time,ysum);
    title('y Magnetization');
    axis([min(time) max(time) -1 1]);
    subplot(3,2,6);
    plot(time,zsum);
    title('z Magnetization');
    axis([min(time) max(time) -1 1]);
    fname = sprintf('%0i.png',Sim.frame);
    image = getframe(gcf);
    imwrite(image.cdata,fname,'png');
    Sim.frame=Sim.frame+1;
    pause(Sim.delay);
end

for k=1:mdegrees(1)
    r(k)=((ends(k,1)-0)^2+(ends(k,2)-0)^2+(ends(k,3)-0)^2)^0.5;
end

angles = vec2ang(ends)'*180/3.14159265358979323846;
Spinsout = [angles r'];
Frameout=Sim.frame;
end
