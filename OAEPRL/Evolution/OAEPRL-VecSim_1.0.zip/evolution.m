%% Bloch Evolution Function
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% Pulse EPR Vector Simulation Package, Version 1.0
% Last Modified 05/05/2011

function f=evolution(Spins,Sim) % Establishes the function and inputs

if (isfield(Spins,'Tone') == 0); % If statement to check for empty field
    Spins.Tone=0.0002; % Sets the empty field
end % ends the if statement

if (isfield(Spins,'Ttwo') == 0); % If statement to check for empty field
    Spins.Ttwo=0.000002; % Sets the empty field
end % ends the if statement

if (isfield(Spins,'Tone') == 0); % If statement to check for empty field
    Spins.Tone=0.0002; % Sets the empty field
end % ends the if statement

if (isfield(Sim,'length') == 0); % If statement to check for empty field
    Sim.length=0.0000005; % Sets the empty field
end % ends the if statement

if (isfield(Sim,'inc') == 0); % If statement to check for empty field
    Sim.inc=0.00000001; % Sets the empty field
end % ends the if statement

if (isfield(Sim,'delay') == 0); % If statement to check for empty field
    Sim.delay=0.05; % Sets the empty field
end % ends the if statement

mdegrees = size(Spins.degrees); % Gets the number of spins in the input
starts = zeros(mdegrees(1),3); % Generates an origin matrix

for i=1:mdegrees(1) % Begins the for loop to convert the spins from polar to rectangular coordinates
    x = sin(Spins.degrees(i,2)/360*2*3.14159265358979323846)*cos(Spins.degrees(i,1)/360*2*3.14159265358979323846)*Spins.degrees(i,3); % Mx projection
    y = sin(Spins.degrees(i,2)/360*2*3.14159265358979323846)*sin(Spins.degrees(i,1)/360*2*3.14159265358979323846)*Spins.degrees(i,3); % My projection
    z = cos(Spins.degrees(i,2)/360*2*3.14159265358979323846)*Spins.degrees(i,3); % Mz projection
    coordinates(i,:)=[x,y,z]; % Collects all of the coordinates into one matrix
end % ends for loop

points=1; % establishes increment variable
for t=0:Sim.inc:Sim.length; % Begins for loop to increment the time
    time(1,points)=t; % Creates time array
    xsum(1,points)=0; % Creates x array
    ysum(1,points)=0; % Creates y array
    zsum(1,points)=0; % Creates z array
    points=points+1; % Incrments the points variable
end % ends for loop

for m=1:mdegrees(1) % Establishes for loop to get the initial transverse and longitudinal projections
    xyprojection(m) = (coordinates(m,1)^2+coordinates(m,2)^2)^0.5; % Calclulates the xy projection
    zprojection(m) = coordinates(m,3); % calculates the z projection
end % ends for loop

points=1;
for t=0:Sim.inc:Sim.length; % Begins for loop to increment the time
    for j=1:mdegrees(1) % Establishes the for loop to let the spins evolve
        scale=xyprojection(j).*(2.71828183^(-t./Spins.Ttwo)); % Determines a scale factor based on T2 decay
        coordinates(j,:) = coordinates(j,:)*rotaxi2mat([0;0;1],2*pi*Spins.offset(j)*Sim.inc); % Rotates the spins along z axis
        relaxation(j,1)=coordinates(j,1).*xyprojection(j).*(2.71828183^(-t./Spins.Ttwo)); % Scales x coordinate based on T2
        relaxation(j,2)=coordinates(j,2).*xyprojection(j).*(2.71828183^(-t./Spins.Ttwo)); % Scales y coordinate based on T2
        relaxation(j,3)=1+(zprojection(j)-1).*(2.71828183^(-t./Spins.Tone)); % Scales the z coordinate based on T1
        ends(j,:)=relaxation(j,:); % Creates a matrix of the spins
    end % ends for loop
    xsum(1,points)=round(sum(ends(:,1))/mdegrees(1)*100)/100; % Sums all of the x coordinates and scales them by the number of spins
	ysum(1,points)=round(sum(ends(:,2))/mdegrees(1)*100)/100; % Sums all of the y coordinates and scales them by the number of spins
    zsum(1,points)=round(sum(ends(:,3))/mdegrees(1)*100)/100; % Sums all of the z coordinates and scales them by the number of spins
    subplot(1,2,1) % Establishes the sublot for the vector diagram
    quiver3(starts(:,1),starts(:,2),starts(:,3),ends(:,1),ends(:,2),ends(:,3)); % Plots the 3D data
    xlabel('x'); % Creates an axis label
    ylabel('y'); % Creates an axis label
    zlabel('z'); % Creates an axis label
    title('Vector Diagram Simulation'); % Constructs the title
    axis ([-1 1 -1 1 -1 1]); % Sets the axes sizes
    subplot(3,2,2); % Subplot for x magnetization
    plot(time,xsum); % Plots x magnetization
    title('x Magnetization'); % Constructs the title
    axis([min(time) max(time) -1 1]); % Sets axis limits
    subplot(3,2,4); % Subplot for y magnetization
    plot(time,ysum); % Plots y magnetization
    title('y Magnetization'); % Constructs the title
    axis([min(time) max(time) -1 1]); % Sets axis limits
    subplot(3,2,6); % Subplot for z magnetization
    plot(time,zsum); % Plots z magnetization
    title('z Magnetization'); % Constructs the title
    axis([min(time) max(time) -1 1]); % Sets axis limits
    pause(Sim.delay); % Introduces a delay to create animation effect
    points=points+1; % Increments the points variable
end % ends the for loop

for k=1:mdegrees(1) % Begins for loop to get r for polar coordinates
    r(k)=((ends(k,1)-0)^2+(ends(k,2)-0)^2+(ends(k,3)-0)^2)^0.5; % Calculates r
end % ends the for loop

angles = vec2ang(ends)'*180/3.14159265358979323846; % uses EasySpin to get the angles from the rectangular coordinates
f = [angles r']; % Writes the final coordinates from the simulation
