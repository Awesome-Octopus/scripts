%% Pulse Function
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% Pulse EPR Vector Simulation Package, Version 1.0
% Last Modified 05/05/2011

function f=pulse(Spins,Pulse) % Establishes the function and inputs

if (isfield(Pulse,'angle') == 0); % If statement to check for empty field
    Pulse.angle=90; % Sets the empty field
end % ends the if statement

if (isfield(Pulse,'direction') == 0); % If statement to check for empty field
    Pulse.direction='y'; % Sets the empty field
end % ends the if statement

if (isfield(Pulse,'delay') == 0); % If statement to check for empty field
    Pulse.delay=0.02; % Sets the empty field
end % ends the if statement

mdegrees = size(Spins.degrees); % Gets the number of spins in the input
starts = zeros(mdegrees(1),3); % Generates an origin matrix
angle = Pulse.angle/360*2*3.14159265358979323846; % Converts the pulse angle to radians

if ( Pulse.direction == 'x'); % If statement tsting for pulse axis
    rotaxis = [1;0;0]; % Sets rotation axis along x
elseif ( Pulse.direction == 'y'); % If statement tsting for pulse axis
    rotaxis = [0;1;0]; % Sets rotation axis along y
elseif ( Pulse.direction == '-x'); % If statement tsting for pulse axis
    rotaxis = [-1;0;0]; % Sets rotation axis along -x
elseif ( Pulse.direction == '-y'); % If statement tsting for pulse axis
    rotaxis = [0;-1;0]; % Sets rotation axis along -y
end % ends the if statement

for i=1:mdegrees(1) % Begins the for loop to convert the spins from polar to rectangular coordinates
    x = sin(Spins.degrees(i,2)/360*2*3.14159265358979323846)*cos(Spins.degrees(i,1)/360*2*3.14159265358979323846)*Spins.degrees(i,3); % Mx projection
    y = sin(Spins.degrees(i,2)/360*2*3.14159265358979323846)*sin(Spins.degrees(i,1)/360*2*3.14159265358979323846)*Spins.degrees(i,3); % My projection
    z = cos(Spins.degrees(i,2)/360*2*3.14159265358979323846)*Spins.degrees(i,3); % Mz projection
    coordinates(i,:)=[x,y,z]; % Collects all of the coordinates into one matrix
end % ends for loop

points=1; % Establishes the points variable
for t=1:1:Pulse.angle; % Begins for loop to increment the time
    time(1,points)=t; % Creates time array
    xsum(1,points)=0; % Creates x array
    ysum(1,points)=0; % Creates y array
    zsum(1,points)=0; % Creates z array
    points=points+1; % Incrments the points variable
end % ends the for loop

points=1; % Establishes the points variable
for j=1:Pulse.angle/2 % Starts the for loop to increment the rotation
	coordinates = coordinates*rotaxi2mat(rotaxis,angle/(Pulse.angle/2)); % Rotates the spins
    ends=coordinates; % Creates array for plotting
	xsum(1,points)=round(sum(ends(:,1))/mdegrees(1)*100)/100; % Sums all of the x coordinates and scales them by the number of spins
	ysum(1,points)=round(sum(ends(:,2))/mdegrees(1)*100)/100; % Sums all of the y coordinates and scales them by the number of spins
    zsum(1,points)=round(sum(ends(:,3))/mdegrees(1)*100)/100; % Sums all of the z coordinates and scales them by the number of spins
	subplot(1,2,1) % Establishes the sublot for the vector diagram
    quiver3(starts(:,1),starts(:,2),starts(:,3),ends(:,1),ends(:,2),ends(:,3)); % Plots the 3D data
    xlabel('x'); % Creates an axis label
    ylabel('y'); % Creates an axis label
    zlabel('z'); % Creates an axis label
    title('Vector Diagram Simulation') % Constructs the title
    axis ([-1 1 -1 1 -1 1]); % Sets the axes sizes
    subplot(3,2,2) % Subplot for x magnetization
    plot(time,xsum) % Plots x magnetization
    axis([min(time) max(time) -1 1])
    title('x Magnetization'); % Constructs the title
    subplot(3,2,4) % Subplot for y magnetization
    plot(time,ysum) % Plots y magnetization
    axis([min(time) max(time) -1 1]) % Sets the axes sizes
    title('y Magnetization'); % Constructs the title
    subplot(3,2,6) % Subplot for z magnetization
    plot(time,zsum) % Plots z magnetization
    axis([min(time) max(time) -1 1]) % Sets the axes sizes
    title('z Magnetization'); % Constructs the title
    points=points+1; % Increments the points variable
    pause(Pulse.delay); % Introduces a delay to create animation effect
end % ends the for loop

for k=1:mdegrees(1) % Begins for loop to get r for polar coordinates
    r(k)=((ends(k,1)-0)^2+(ends(k,2)-0)^2+(ends(k,3)-0)^2)^0.5; % Calculates r
end % ends the for loop

angles = vec2ang(ends)'*180/3.14159265358979323846; % uses EasySpin to get the angles from the rectangular coordinates
f = [angles r']; % Writes the final coordinates from the simulation
