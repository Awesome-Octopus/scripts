clear all

%% Creates a matrix of spins along the z axis

for i=1:250
    Spins.degrees(i,:) = [0,0,1];
end

%% Sets the parameters and function for first pi/2 pulse

Pulse.direction = 'y';
Pulse.angle = 90;
Pulse.delay = 0.002;

Spins.degrees = pulse(Spins,Pulse);

%% Sets the evolution parameters and function between pulses

Spins.Tone = 0.0002;
Spins.Ttwo = 0.00002;
Spins.offset = linspace(-16000000,16000000,250);

Sim.length = 0.0000002;
Sim.inc = 0.000000002;
Sim.delay = 0.1;

Spins.degrees = evolution(Spins,Sim);

%% Sets the parameters and function for second pi/2 pulse

Pulse.direction = 'y';
Pulse.angle = 90;
Pulse.delay = 0.002;

Spins.degrees = pulse(Spins,Pulse);

%% Sets the evolution parameters and function between pulses

Sim.length = 0.000001;
Sim.inc = 0.00000001;

Spins.degrees = evolution(Spins,Sim);

%% Sets the parameters and function for first pi/2 pulse

Pulse.direction = 'y';
Pulse.angle = 90;
Pulse.delay = 0.002;

Spins.degrees = pulse(Spins,Pulse);

%% Sets the evolution parameters and function after pulses

Sim.length = 0.000003;
Sim.inc = 0.00000003;

Spins.degrees = evolution(Spins,Sim);