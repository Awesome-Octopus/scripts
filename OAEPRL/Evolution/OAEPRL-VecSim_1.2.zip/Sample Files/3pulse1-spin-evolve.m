clear all

%% Creates a matrix of spins along the z axis

Sim.video = 'y'

Spins.degrees = [0,30,1];

Spins.Tone = 1;
Spins.Ttwo = 1;
Spins.offset = 16000000

Sim.length = 0.0000002;
Sim.inc = 0.000000002;
Sim.delay = 0.1;

[Spins.degrees Sim.frame] = evolution(Spins,Sim);