clear all

%% Creates a matrix of spins along the z axis

Spins.degrees = [0,0,0.7;0,0,0.25;0,0,0.5;0,0,0.5;0,0,0.25;0,0,0.5;0,0,1;0,0,0.5;];

%% Sets the parameters and function for first pi/2 pulse

Sim.direction = 'y';
Sim.angle = 90;
Sim.delay = 0.002;
Spins.degrees = pulse(Spins,Sim);

%% Sets the evolution parameters and function between pulses

Spins.Tone = 1;
Spins.Ttwo = 0.05;
Spins.offset = [4.7 3.59 3.57 3.55 3.53 1.12 1.11 1.10].*1e-6*200000000;

Sim.length = 0.1;
Sim.inc = 0.0001;
Sim.delay = 0.05;

Spins.degrees = evolution(Spins,Sim);