%% Pulse Function
% Ohio Advanced EPR Laboratory
% Rob McCarrick
% Pulse EPR Vector Simulation Package, Version 1.22
% Last Modified 10/12/2011

function [Spinsout,Frameout]=pulse(Spins,Sim)

%% Checks for variables and falls back on a default value if missing

if (isfield(Sim,'video') == 0)
    Sim.video='n';
end

if (isfield(Sim,'frame') == 0);
    Sim.frame=10000;
end

if (isfield(Sim,'angle') == 0);
    Sim.angle=90;
end

if (isfield(Sim,'direction') == 0);
    Sim.direction='y';
end

if (isfield(Sim,'delay') == 0);
    Sim.delay=0.02;
end

%% Sets the rotation axis based on the input
angle = Sim.angle/360*2*pi;
theta=angle/(Sim.angle/2);
if (Sim.direction == 'x');
    rotmat = [1 0 0;0 cos(-theta) -sin(-theta);0 sin(-theta) cos(-theta)];
elseif (Sim.direction == 'y');
    rotmat = [cos(-theta) 0 sin(-theta);0 1 0;-sin(-theta) 0 cos(-theta)];
elseif (Sim.direction == '-x');
    rotmat = [1 0 0;0 cos(theta) -sin(theta);0 sin(theta) cos(theta)];
elseif (Sim.direction == '-y');
    rotmat = [cos(theta) 0 sin(theta);0 1 0;-sin(theta) 0 cos(theta)];
end

%% Gets the number of spins in the array

mdegrees = size(Spins.degrees);
starts = zeros(mdegrees(1),3);

%% Converts spins to rectangular coordinates

for i=1:mdegrees(1)
    x = sin(Spins.degrees(i,2)/360*2*pi)*cos(Spins.degrees(i,1)/360*2*pi)*Spins.degrees(i,3);
    y = sin(Spins.degrees(i,2)/360*2*pi)*sin(Spins.degrees(i,1)/360*2*pi)*Spins.degrees(i,3);
    z = cos(Spins.degrees(i,2)/360*2*pi)*Spins.degrees(i,3);
    coordinates(i,:)=[x,y,z];
end

%% Creates time axes for the plots

time = 1:2:Sim.angle;
xsum = zeros(1,numel(time));
ysum = zeros(1,numel(time));
zsum = zeros(1,numel(time));

if (Sim.video == 'n');

%% Conducts the rotaition about z and plots the results

for j=1:Sim.angle/2
	coordinates = coordinates*rotmat;
    ends=coordinates;
	xsum(1,j)=round(sum(ends(:,1))/mdegrees(1)*100)/100;
	ysum(1,j)=round(sum(ends(:,2))/mdegrees(1)*100)/100;
    zsum(1,j)=round(sum(ends(:,3))/mdegrees(1)*100)/100;
	subplot(1,2,1)
    quiver3(starts(:,1),starts(:,2),starts(:,3),coordinates(:,1),coordinates(:,2),coordinates(:,3));
    hold on
    plot3([1 0],[0 0],[0 0],'k')
    plot3([0 0],[1 0],[0 0],'k')
    plot3([0 0],[0 0],[1 0],'k')
    text(1.1,0,0,'X_R')
    text(0,1.1,0,'Y_R')
    text(0,0,1.1,'Z_R')
    hold off
    set(gca,'XDir','rev','YDir','rev','GridLineStyle','none','XTick',[],'YTick',[],'ZTick',[]);
    title('Vector Diagram Simulation')
    axis ([-1 1 -1 1 -1 1]);
    subplot(3,2,2)
    plot(time,xsum)
    axis([min(time) max(time) -1 1])
    ylabel('M_X');
    xlabel('degree rotation');
    subplot(3,2,4)
    plot(time,ysum)
    axis([min(time) max(time) -1 1])
    ylabel('M_Y');
    xlabel('degree rotation');
    subplot(3,2,6)
    plot(time,zsum)
    axis([min(time) max(time) -1 1])
    ylabel('M_Z');
    xlabel('degree rotation');
    pause(Sim.delay);
end

for k=1:mdegrees(1)
    r(k)=((ends(k,1)-0)^2+(ends(k,2)-0)^2+(ends(k,3)-0)^2)^0.5;
end

for l=1:mdegrees(1)
    angles(l,:)= [atan2(ends(l,2),ends(l,1))*180/pi acos(ends(l,3)/r(l))*180/pi];
end

Spinsout = [angles r'];
Frameout = 0;

elseif (Sim.video == 'y');

%% Conducts the rotaition about z and plots the results

for j=1:Sim.angle/2
	coordinates = coordinates*rotmat;
    ends=coordinates;
	xsum(1,j)=round(sum(ends(:,1))/mdegrees(1)*100)/100;
	ysum(1,j)=round(sum(ends(:,2))/mdegrees(1)*100)/100;
    zsum(1,j)=round(sum(ends(:,3))/mdegrees(1)*100)/100;
	subplot(1,2,1)
    quiver3(starts(:,1),starts(:,2),starts(:,3),ends(:,1),ends(:,2),ends(:,3));
    hold on
    plot3([1 0],[0 0],[0 0],'k')
    plot3([0 0],[1 0],[0 0],'k')
    plot3([0 0],[0 0],[1 0],'k')
    text(1.1,0,0,'X_R')
    text(0,1.1,0,'Y_R')
    text(0,0,1.1,'Z_R')
    hold off
    set(gca,'XDir','rev','YDir','rev','GridLineStyle','none','XTick',[],'YTick',[],'ZTick',[]);
    title('Vector Diagram Simulation')
    axis ([-1 1 -1 1 -1 1]);
    subplot(3,2,2)
    plot(time,xsum)
    axis([min(time) max(time) -1 1])
    ylabel('M_X');
    xlabel('degree rotation');
    subplot(3,2,4)
    plot(time,ysum)
    axis([min(time) max(time) -1 1])
    ylabel('M_Y');
    xlabel('degree rotation');
    subplot(3,2,6)
    plot(time,zsum)
    axis([min(time) max(time) -1 1])
    ylabel('M_Z');
    xlabel('degree rotation');
    fname = sprintf('%0i.png',Sim.frame);
    image = getframe(gcf);
    imwrite(image.cdata,fname,'png');
    Sim.frame = Sim.frame+1
    pause(Sim.delay);
end

for k=1:mdegrees(1)
    r(k)=((ends(k,1)-0)^2+(ends(k,2)-0)^2+(ends(k,3)-0)^2)^0.5;
end

for l=1:mdegrees(1)
    angles(l,:)= [atan2(ends(l,2),ends(l,1))*180/pi acos(ends(l,3)/r(l))*180/pi];
end

Spinsout = [angles r'];
Frameout = Sim.frame;
end