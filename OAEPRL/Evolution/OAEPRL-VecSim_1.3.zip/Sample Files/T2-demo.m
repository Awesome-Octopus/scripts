clear all

%% Creates a matrix of spins along the z axis

for i=1:5
    Spins.degrees(i,:) = [0,0,1];
end

%% Sets the parameters and function for first pi/2 pulse

Pulse.direction = 'y';
Pulse.angle = 90;
Pulse.delay = 0.002;

Spins.degrees = pulse(Spins,Pulse);

%% Sets the evolution parameters and function between pulses

Spins.Tone = 0.005;
Spins.Ttwo = 0.0000115;
Spins.offset = linspace(-50000,50000,5);

Sim.length = 0.00007;
Sim.nframes = 100;
Sim.delay = 0.05;

Spins.degrees = evolution(Spins,Sim);