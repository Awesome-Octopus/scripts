clear all

Sim.video = 'y';
%% Creates a matrix of spins along the z axis

for i=1:250
    Spins.degrees(i,:) = [0,0,1];
end

%% Sets the parameters and function for first pi/2 pulse

Sim.direction = 'y';
Sim.angle = 90;
Sim.delay = 0.002;

[Spins.degrees Sim.frameindex] = pulse(Spins,Sim);

%% Sets the evolution parameters and function between pulses

Spins.Tone = 0.000219;
Spins.Ttwo = 0.0000115;
Spins.offset = linspace(-1600000,1600000,250);

Sim.length = 0.0000005;
Sim.delay = 0.05;

[Spins.degrees Sim.frameindex] = evolution(Spins,Sim);

%% Sets the parameters and function for pi pulse

Sim.direction = 'y';
Sim.angle = 180;
Sim.delay = 0.01;

[Spins.degrees Sim.frame] = pulse(Spins,Sim);

%% Sets the evolution parameters and function after pulses

Sim.length = 0.0000016;

[Spins.degrees Sim.frameindex] = evolution(Spins,Sim);
