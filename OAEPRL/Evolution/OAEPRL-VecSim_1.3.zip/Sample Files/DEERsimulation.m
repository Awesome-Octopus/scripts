clear all

%% Sets up the pump pulse timing and ee coupling.
% Changing the timing moves the pump pulse
% eecoupling is the dipolar coupling for one orientation

timing = 200e-9;
eecoupling = 3e6;

%%  Carries out the DEER Pulse sequence

% Sets up the spins along the Z axis
for i=1:250;
	Spins.degrees(i,:) = [0,0,1];
end

Spins.offset = linspace(-16e6,16e6,250);

% pi/2 pulse

Sim.direction = 'y';
Sim.angle = 90;
Sim.nframes = 30;

Spins.degrees = pulse(Spins,Sim);

% tau

Sim.length = 200e-9;
Sim.nframes = 50;

Spins.degrees = evolution(Spins,Sim);

% first pi pulse

Sim.direction = 'y';
Sim.angle = 180;
Sim.nframes = 60;

Spins.degrees = pulse(Spins,Sim);

% time between pi pulse and pump pulse

Sim.length = timing;
Sim.nframes = round(200*(timing/(0.0000012-timing)));

Spins.degrees = evolution(Spins,Sim);

% changes the precesion frequnecy for 10% of the spins according to the
% eecoupling

for i=226:250;
    Spins.offset(i) = Spins.offset(i)-eecoupling;
end

% time between pump pulse and refocusing pulse

Sim.length = 0.0000012-timing;
Sim.nframes = round(200*(0.0000012-timing)/0.0000012);

Spins.degrees = evolution(Spins,Sim);

% refocusing pulse

Sim.direction = 'y';
Sim.angle = 180;
Sim.nframes = 60;

Spins.degrees = pulse(Spins,Sim);

% time between refocussing pulse and the top of the redocussed echo

Sim.length = 0.000001;
Sim.nframes = 100;

Spins.degrees = evolution(Spins,Sim);

