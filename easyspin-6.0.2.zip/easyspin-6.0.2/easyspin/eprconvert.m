% eprconvert Frequency/field/g value conversion utility 
%
%   eprconvert
%
%   A dialog for conversion of frequency and field units and
%   for computation of one of frequeny/field/g value from the
%   two other quantities using the equation
%
%      planck*frequency = bmagn*field*g
