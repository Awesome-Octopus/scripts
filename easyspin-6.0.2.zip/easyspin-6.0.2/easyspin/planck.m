% planck  Planck constant 
%
%   h = planck
%
%   Returns the Planck constant in SI units, joule times second.
