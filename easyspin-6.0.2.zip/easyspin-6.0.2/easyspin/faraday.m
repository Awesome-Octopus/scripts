% faraday  Faraday constant 
%
%   F = faraday
%
%   Returns the Faraday constant in SI units, coulomb per mole.
