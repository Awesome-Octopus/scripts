% clight  Speed of light 
% 
%   c = clight
%
%   Returns the vacuum speed of light in
%   SI units, meters per second.
