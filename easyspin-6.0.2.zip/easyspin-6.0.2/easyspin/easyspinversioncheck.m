% easyspinversioncheck Checks online for a new version 
