% avogadro  Avogadro number 
%
%   N = avogadro
%
%   Returns the Avogadro constant
%   in mol^-1.
