% echarge  Elementary charge 
%
%   e = echarge
%
%   Returns the elementary charge in SI units, in coulomb.
