% isotopes   Graphical interface for nuclear isotope data 
%
%   Displays a periodic table of the elements with
%   a table of nuclear isotopes.
%
